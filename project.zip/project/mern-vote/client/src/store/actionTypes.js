export const ADD_ERROR = 'ADD_ERROR';
export const REMOVE_ERROR = 'REMOVE_ERROR';

export const SET_CURRENT_USER = 'SET_CURRENT_USER';

export const SET_POLLS = 'SET_POLLS';
export const SET_CURRENT_POLL = 'SET_CURRENT_POLL';
